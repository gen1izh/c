#ifndef _MAIN_
#define _MAIN_

enum {
  SUCCESSFUL = 0,
  NO_MEMORY,
  UNKNOWN_ERROR
};

#endif
